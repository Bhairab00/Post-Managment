import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";

interface Post {
  id: number;
  title: string;
  body: string;
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // In-memory storage
  let posts: Post[] = [
    { id: 1, title: "Hello World", body: "My first post" },
    { id: 2, title: "Getting Started", body: "This is a simple post management app." }
  ];
  let nextId = 3;

  // API Routes
  app.get("/api/posts", (req, res) => {
    res.json(posts);
  });

  app.post("/api/posts", (req, res) => {
    const { title, body } = req.body;

    if (!title || !body) {
      return res.status(400).json({ error: "Title and body are required" });
    }

    const newPost: Post = {
      id: nextId++,
      title,
      body
    };

    posts.push(newPost);
    res.status(201).json(newPost);
  });

  app.delete("/api/posts/:id", (req, res) => {
    const id = parseInt(req.params.id);
    const initialLength = posts.length;
    posts = posts.filter(post => post.id !== id);

    if (posts.length === initialLength) {
      return res.status(404).json({ error: "Post not found" });
    }

    res.status(204).send();
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
